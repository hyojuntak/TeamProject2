package dao;

import vo.Ingredients;

public interface IngredientsDAO {
	public int insertIngredients(Ingredients ingredients);
	
	public int updateIngredients(Ingredients ingredients);
	
	public int deleteIngredients(String date);
	
	public int clearDummy();
	
	public int deleteAllIngre();
}
