package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import vo.DailyStocks;

public class DailyStocksDAOManager {
	private SqlSessionFactory factory = MybatisConfig.getSqlSessionFactory();

	// ���� ���ں� ��� �����͸� ��ȸ
	public List<DailyStocks> selectDailyStocks() {
		SqlSession session = factory.openSession();
		DailyStocksDAO dao = session.getMapper(DailyStocksDAO.class);
		List<DailyStocks> list = dao.selectDailyStocks();
		session.close();
		return list;
	}
}
