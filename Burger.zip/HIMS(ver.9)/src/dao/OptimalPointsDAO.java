package dao;

import java.util.List;
import java.util.Map;

import vo.Ingredients;
import vo.MetaPI;
import vo.Optimals;
import vo.OptimalsI;
import vo.ProductsInfo;
import vo.Sales;
import vo.TimeSales;
import vo.UpdateCorrelation;
import vo.UpdateIngredients;
import vo.UseIngredients;

public interface OptimalPointsDAO {
	public List<TimeSales> selectTimeSales(Map<String, Object> map);
	
	public double getAvgTime(Map<String, Object> map);
	
	public double getAvgSales(Map<String, Object> map);
	
	public int updateCorrelation(UpdateCorrelation uc);
	
	public Double getCorr(int i);
		
	public int updateDemand(Optimals optimals);
	
	public Optimals selectOptimals(int i);
	
	public List<Sales> selectSales(int i);
	
	public List<Integer> getLeftAmount();
	
	public List<Integer> getDemandForecast();
	
	public List<Integer> getDeliveryTime();
	
	public Integer getAmount(MetaPI metaPI);
	
	public int updateOptimalTime(Map<String, Object> map);
	
	public int updateLeftAmount(Map<String, Object> map);
	
	public int updateIngredientsForecast(Map<String, Object> map);
	
	public List<OptimalsI> selectOptimalsI();
	
	public List<UseIngredients> getUseIngredients(Map<String, Object> map);
	
	public Ingredients getShortestIngredients(UseIngredients ui);
	
	public int updateIngredients(UpdateIngredients ui);
	
	public int deleteIngredients(Ingredients ingredients);
	
	public int clearIngredients();
	
	public int setSmoothingCoefficient(Double x);
	
	public int setAnalysisPeriod(int x);
	
	public Double getSmoothingCoefficient();
	
	public Integer getAnalysisPeriod();
	
	public int setFirstForecast(Map<String, Object> map);
	
	public Integer getFirstForecast(int x);
	
	public List<ProductsInfo> selectProductsInfo();
}
