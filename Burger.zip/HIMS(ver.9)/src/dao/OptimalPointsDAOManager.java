package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import vo.Ingredients;
import vo.MetaPI;
import vo.Optimals;
import vo.OptimalsI;
import vo.ProductsInfo;
import vo.Sales;
import vo.TimeSales;
import vo.UpdateCorrelation;
import vo.UpdateIngredients;
import vo.UseIngredients;

public class OptimalPointsDAOManager {
	private SqlSessionFactory factory = MybatisConfig.getSqlSessionFactory();

	// ������Ʈ �� �ļ� �۾���
	public void setting() {
		IngredientsStocksDAOManager ismanager = new IngredientsStocksDAOManager();
		clearIngredients();
		ismanager.updateOptimalI();
		updateCorrelation();
		updateDemandForecast();
		updateOptimalTime();
	}

	// ��Ȱ��� setter
	public int setSmoothingCoefficient(double x) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		int result = dao.setSmoothingCoefficient(x);
		session.commit();
		session.close();
		return result;
	}

	// ��Ȱ��� getter
	public Double getSmoothingCoefficient() {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		double x = dao.getSmoothingCoefficient();
		session.close();
		return x;
	}

	// �м� �Ⱓ setter
	public int setAnalysisPeriod(int x) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		int result = dao.setAnalysisPeriod(x);
		session.commit();
		session.close();
		return result;
	}

	// �м� �Ⱓ getter
	public int getAnalysisPeriod() {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		int x = dao.getAnalysisPeriod();
		session.close();
		return x;
	}

	// ��ǰ�� ���� ���� �Ǹŷ� setter
	public int setFirstForecast(Map<String, Object> map) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		int result = dao.setFirstForecast(map);
		session.commit();
		session.close();
		return result;
	}

	// ��ǰ�� ���� ���� �Ǹŷ� getter
	public int getFirstForecast(int x) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		int y = dao.getFirstForecast(x);
		session.close();
		return y;
	}

	// ������ ���ϱ�
	public int updateCorrelation() {
		int result = 0;
		result += subUpdateCorr(1);
		result += subUpdateCorr(2);
		result += subUpdateCorr(3);
		result += subUpdateCorr(4);
		result += subUpdateCorr(5);
		return result;
	}

	private int subUpdateCorr(int i) {
		double corr = 0;
		double avgTime = 0;
		double time = 0;
		double avgSales = 0;
		double sales = 0;
		double upper = 0;
		double lower = 0;
		double lowerTime = 0;
		double lowerSales = 0;

		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);

		Map<String, Object> map = new HashMap<>();
		map.put("analPeriod", dao.getAnalysisPeriod());
		map.put("p_no", i);
		avgTime = dao.getAvgTime(map);
		avgSales = dao.getAvgSales(map);

		List<TimeSales> tslist = dao.selectTimeSales(map);

		for (TimeSales ts : tslist) {
			time = ts.getTime();
			sales = ts.getP_amount();
			upper += (time - avgTime) * (sales - avgSales);
			lowerTime += (time - avgTime) * (time - avgTime);
			lowerSales += (sales - avgSales) * (sales - avgSales);
		}
		lower = Math.sqrt(lowerTime * lowerSales);
		corr = upper / lower;
		int result = 0;
		if (!Double.isNaN(corr)) {
			result = dao.updateCorrelation(new UpdateCorrelation(i, corr));
			session.commit();
		}
		session.commit();
		session.close();
		return result;
	}

	// ���� ���� ���䷮ �Է��ϱ�
	public int updateDemandForecast() {
		int result = 0;
		result += subUpdateDemandForecast(1);
		result += subUpdateDemandForecast(2);
		result += subUpdateDemandForecast(3);
		result += subUpdateDemandForecast(4);
		result += subUpdateDemandForecast(5);
		return result;
	}

	private int subUpdateDemandForecast(int i) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		int result = 0;
		double forecast = 0;
		Optimals op = dao.selectOptimals(i);
		List<Sales> slist = dao.selectSales(i);
		forecast = op.getFirst_forecast();
		for (int j = 0; j < slist.size(); j++) {
			forecast = getSmoothingCoefficient() * slist.get(j).getP_amount()
					+ (1 - getSmoothingCoefficient()) * forecast;
		}
		result = dao.updateDemand(new Optimals(i, (int) forecast));
		session.commit();
		session.commit();
		session.close();
		return result;
	}

	// ���� ���� �ñ� �Է� + ��Ằ ���� ���� ���䷮ �Է�, ��Ằ ���� �� ����� �Է�
	public int updateOptimalTime() {
		int result = 0;
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);

		List<Integer> leftAmount = null;
		List<Integer> demandForecast = null;
		List<Integer> deliveryTime = null;
		List<Integer> optimalOrderTime = new ArrayList<>();
		List<Integer> ingredientsDemandForecast = new ArrayList<>();
		int i_amount = 0;

		leftAmount = dao.getLeftAmount();
		demandForecast = dao.getDemandForecast();
		deliveryTime = dao.getDeliveryTime();

		// �� ��ǰ�� ���� ������ �翡 ���� ���䷮�� ���� ��Ằ ���� ���䷮ �Է�
		for (int j = 0; j < leftAmount.size(); j++) {
			for (int k = 0; k < demandForecast.size(); k++) {
				MetaPI metaPI = new MetaPI(k + 1, j + 1);
				if (dao.getAmount(metaPI) != null) {
					i_amount += demandForecast.get(k) * dao.getAmount(metaPI);
				}
			}
			ingredientsDemandForecast.add(i_amount);
			i_amount = 0;
		}

		// ��Ằ ���� ���� ���䷮ �Է�
		updateIngredientsForecast(ingredientsDemandForecast);
		// ��Ằ ���� �� ����� �Է�
		updateLeftAmount(leftAmount);
		// ����� �� �������� �� ������ ���� �� �ִ� ���� ���� ������ �Է�
		for (int j = 0; j < leftAmount.size(); j++) {
			if (ingredientsDemandForecast.get(j) == 0) {
				optimalOrderTime.add(null);
				continue;
			}
			int orderTime = leftAmount.get(j) / ingredientsDemandForecast.get(j) - deliveryTime.get(j);
			optimalOrderTime.add(orderTime);
		}

		for (int j = 0; j < optimalOrderTime.size(); j++) {
			if (optimalOrderTime.get(j) == null)
				continue;
			Map<String, Object> map = new HashMap<>();
			map.put("optimal_time", optimalOrderTime.get(j));
			map.put("i_no", j + 1);
			result += dao.updateOptimalTime(map);
			session.commit();
		}
		session.commit();
		session.close();
		return result;
	}

	// ���ǰ�� ���� ���䷮ �Է�
	private void updateIngredientsForecast(List<Integer> ingredientsDemandForecast) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);

		for (int j = 0; j < ingredientsDemandForecast.size(); j++) {
			Map<String, Object> map = new HashMap<>();
			map.put("forecast", ingredientsDemandForecast.get(j));
			map.put("i_no", j + 1);
			dao.updateIngredientsForecast(map);
			session.commit();
		}
		session.commit();
		session.close();
	}

	// ���ǰ�� ���� ����� ����
	private void updateLeftAmount(List<Integer> leftAmount) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		clearIngredients();
		for (int j = 0; j < leftAmount.size(); j++) {
			Map<String, Object> map = new HashMap<>();
			map.put("i_amount", leftAmount.get(j));
			map.put("i_no", j + 1);
			dao.updateLeftAmount(map);
			session.commit();
		}
		session.commit();
		session.close();
	}

	// view ����(���� ���ֽ��� ã�⿡ �ش��ϴ� view)
	public List<OptimalsI> selectOptimalsI() {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		List<OptimalsI> oilist = dao.selectOptimalsI();
		session.close();
		return oilist;
	}

	// ������� ���� ��� �����͵� �����ϱ�
	public void clearIngredients() {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		dao.clearIngredients();
		session.commit();
		session.close();
	}

	// �Ż� ������ �Է� �� ����� ��ŭ�� ����� ���ҽ�Ű��
	public void updateIngredients(Sales sales) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		clearIngredients();
		List<UseIngredients> uilist = getUseIngredients(sales);

		// ����� ��������� ���� ª�� ���� ���� ����Ѵٴ� ���� �Ͽ� ������� ���ҽ�Ű�� �ڵ�
		for (UseIngredients ui : uilist) {
			Ingredients ingredients = getShortestIngredients(ui);
			if (ingredients == null)
				continue;
			if (ui.getI_amount() >= ingredients.getI_amount()) {
				while (true) {
					if (ingredients == null)
						break;
					if (ui.getI_amount() >= ingredients.getI_amount()) {
						dao.deleteIngredients(ingredients);
						session.commit();
						ui.setI_amount(ui.getI_amount() - ingredients.getI_amount());
						ingredients = getShortestIngredients(ui);
					} else if (ui.getI_amount() < ingredients.getI_amount()) {
						dao.updateIngredients(
								new UpdateIngredients(ui.getI_no(), ingredients.getOrder_date(), ui.getI_amount()));
						session.commit();
						break;
					}
				}
			} else if (ui.getI_amount() < ingredients.getI_amount()) {
				dao.updateIngredients(
						new UpdateIngredients(ui.getI_no(), ingredients.getOrder_date(), ui.getI_amount()));
				session.commit();
			}
		}

		session.commit();
		session.close();
	}

	// �Ż� �����͸� ���� �׳� ����� ��� ���ϱ�
	public List<UseIngredients> getUseIngredients(Sales sales) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		List<UseIngredients> list = null;

		Map<String, Object> map = new HashMap<>();
		map.put("sales_date", sales.getSales_date());
		map.put("p_no", sales.getP_no());
		session.commit();
		list = dao.getUseIngredients(map);

		session.close();
		return list;
	}

	// ��� �����͸� ��������
	public Ingredients getShortestIngredients(UseIngredients ui) {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		Ingredients ingredients = dao.getShortestIngredients(ui);
		session.close();
		return ingredients;
	}

	// ��ǰ ���� ���
	public List<ProductsInfo> selectProductsInfo() {
		SqlSession session = factory.openSession();
		OptimalPointsDAO dao = session.getMapper(OptimalPointsDAO.class);
		List<ProductsInfo> list = dao.selectProductsInfo();
		session.close();
		return list;
	}
}
