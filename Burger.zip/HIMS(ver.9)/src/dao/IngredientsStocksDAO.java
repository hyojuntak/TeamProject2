package dao;

import java.util.List;

import vo.IngredientsStocks;

public interface IngredientsStocksDAO {
	public List<IngredientsStocks> selectIngredientsStocks();
	
	public int updateOptimalI(IngredientsStocks is);
}
