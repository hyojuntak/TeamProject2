package dao;

import java.util.List;

import vo.DailyStocks;

public interface DailyStocksDAO {
	public List<DailyStocks> selectDailyStocks();
}
