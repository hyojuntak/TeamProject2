package vo;

public class UpdateCorrelation {
	private int p_no;
	private double correlation;

	public UpdateCorrelation() {
		// TODO Auto-generated constructor stub
	}

	public UpdateCorrelation(int p_no, double correlation) {
		super();
		this.p_no = p_no;
		this.correlation = correlation;
	}

	public int getP_no() {
		return p_no;
	}

	public void setP_no(int p_no) {
		this.p_no = p_no;
	}

	public double getCorrelation() {
		return correlation;
	}

	public void setCorrelation(double correlation) {
		this.correlation = correlation;
	}

	@Override
	public String toString() {
		return "UpdateCorrelation [p_no=" + p_no + ", correlation=" + correlation + "]";
	}
}
