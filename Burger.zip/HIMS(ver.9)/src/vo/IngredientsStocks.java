package vo;

public class IngredientsStocks {
	private String i_name;
	private int i_amount;
	private String shortest_end_date;

	public IngredientsStocks() {
		// TODO Auto-generated constructor stub
	}

	public IngredientsStocks(String i_name, int i_amount, String shortest_end_date) {
		super();
		this.i_name = i_name;
		this.i_amount = i_amount;
		this.shortest_end_date = shortest_end_date;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public int getI_amount() {
		return i_amount;
	}

	public void setI_amount(int i_amount) {
		this.i_amount = i_amount;
	}

	public String getShortest_end_date() {
		return shortest_end_date;
	}

	public void setShortest_end_date(String shortest_end_date) {
		this.shortest_end_date = shortest_end_date;
	}

	@Override
	public String toString() {
		return "IngredientsStocks [i_name=" + i_name + ", i_amount=" + i_amount + ", shortest_end_date="
				+ shortest_end_date + "]";
	}
}
