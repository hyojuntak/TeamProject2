package vo;

public class MetaPI {
	private int p_no;
	private int i_no;

	public MetaPI() {
		// TODO Auto-generated constructor stub
	}

	public MetaPI(int p_no, int i_no) {
		super();
		this.p_no = p_no;
		this.i_no = i_no;
	}

	public int getP_no() {
		return p_no;
	}

	public void setP_no(int p_no) {
		this.p_no = p_no;
	}

	public int getI_no() {
		return i_no;
	}

	public void setI_no(int i_no) {
		this.i_no = i_no;
	}

	@Override
	public String toString() {
		return "MetaPI [p_no=" + p_no + ", i_no=" + i_no + "]";
	}
}
