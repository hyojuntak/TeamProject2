package vo;

public class Ingredients {
	private int i_no;
	private String order_date;
	private int i_amount;

	public Ingredients() {
		// TODO Auto-generated constructor stub
	}

	public Ingredients(int i_no, String order_date, int i_amount) {
		super();
		this.i_no = i_no;
		this.order_date = order_date;
		this.i_amount = i_amount;
	}

	public int getI_no() {
		return i_no;
	}

	public void setI_no(int i_no) {
		this.i_no = i_no;
	}

	public String getOrder_date() {
		return order_date;
	}

	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}

	public int getI_amount() {
		return i_amount;
	}

	public void setI_amount(int i_amount) {
		this.i_amount = i_amount;
	}

	@Override
	public String toString() {
		return "Ingredients [i_no=" + i_no + ", order_date=" + order_date + ", i_amount=" + i_amount + "]";
	}
}
