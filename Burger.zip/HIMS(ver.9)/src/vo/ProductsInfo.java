package vo;

public class ProductsInfo {
	private String p_name;
	private int price;
	private double correlation;
	private int demand_forecast;

	public ProductsInfo() {
		// TODO Auto-generated constructor stub
	}

	public ProductsInfo(String p_name, int price, double correlation, int demand_forecast) {
		super();
		this.p_name = p_name;
		this.price = price;
		this.correlation = correlation;
		this.demand_forecast = demand_forecast;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public double getCorrelation() {
		return correlation;
	}

	public void setCorrelation(double correlation) {
		this.correlation = correlation;
	}

	public int getDemand_forecast() {
		return demand_forecast;
	}

	public void setDemand_forecast(int demand_forecast) {
		this.demand_forecast = demand_forecast;
	}

	@Override
	public String toString() {
		return "ProductsInfo [p_name=" + p_name + ", price=" + price + ", correlation=" + correlation
				+ ", demand_forecast=" + demand_forecast + "]";
	}
}
