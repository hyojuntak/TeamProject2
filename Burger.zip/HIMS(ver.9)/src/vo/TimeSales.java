package vo;

public class TimeSales {
	private int p_no;
	private int time;
	private int p_amount;

	public TimeSales() {
		// TODO Auto-generated constructor stub
	}

	public TimeSales(int p_no, int time, int p_amount) {
		super();
		this.p_no = p_no;
		this.time = time;
		this.p_amount = p_amount;
	}

	public int getP_no() {
		return p_no;
	}

	public void setP_no(int p_no) {
		this.p_no = p_no;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getP_amount() {
		return p_amount;
	}

	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}

	@Override
	public String toString() {
		return "TimeSales [p_no=" + p_no + ", time=" + time + ", p_amount=" + p_amount + "]";
	}
}
