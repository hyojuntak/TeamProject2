package vo;

public class DailySales {
	private String sales_date;
	private int total_income;
	private double total_cost;
	private int net_income;

	public DailySales() {
		// TODO Auto-generated constructor stub
	}

	public DailySales(String sales_date, int total_income, double total_cost, int pure_income) {
		super();
		this.sales_date = sales_date;
		this.total_income = total_income;
		this.total_cost = total_cost;
		this.net_income = pure_income;
	}

	public String getSales_date() {
		return sales_date;
	}

	public void setSales_date(String sales_date) {
		this.sales_date = sales_date;
	}

	public int getTotal_income() {
		return total_income;
	}

	public void setTotal_income(int total_income) {
		this.total_income = total_income;
	}

	public double getTotal_cost() {
		return total_cost;
	}

	public void setTotal_cost(double total_cost) {
		this.total_cost = total_cost;
	}

	public int getNet_income() {
		return net_income;
	}

	public void setNet_income(int pure_income) {
		this.net_income = pure_income;
	}

	@Override
	public String toString() {
		return "DailySales [sales_date=" + sales_date + ", total_income=" + total_income + ", total_cost=" + total_cost
				+ ", net_income=" + net_income + "]";
	}
}
