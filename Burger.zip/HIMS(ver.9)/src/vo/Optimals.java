package vo;

public class Optimals {
	private int p_no;
	private int first_forecast;
	private double correlation;
	private int demand_forecast;

	public Optimals() {
		// TODO Auto-generated constructor stub
	}
	
	public Optimals(int p_no, int demand_forecast) {
		super();
		this.p_no = p_no;
		this.demand_forecast = demand_forecast;
	}

	public Optimals(int p_no, int first_forcast, double correlation, int demand_forecast) {
		super();
		this.p_no = p_no;
		this.first_forecast = first_forcast;
		this.correlation = correlation;
		this.demand_forecast = demand_forecast;
	}

	public int getP_no() {
		return p_no;
	}

	public void setP_no(int p_no) {
		this.p_no = p_no;
	}

	public int getFirst_forecast() {
		return first_forecast;
	}

	public void setFirst_forecast(int first_forcast) {
		this.first_forecast = first_forcast;
	}

	public double getCorrelation() {
		return correlation;
	}

	public void setCorrelation(double correlation) {
		this.correlation = correlation;
	}

	public int getDemand_forecast() {
		return demand_forecast;
	}

	public void setDemand_forecast(int demand_forecast) {
		this.demand_forecast = demand_forecast;
	}

	@Override
	public String toString() {
		return "Optimals [p_no=" + p_no + ", first_forcast=" + first_forecast + ", correlation=" + correlation
				+ ", demand_forecast=" + demand_forecast + "]";
	}
}
