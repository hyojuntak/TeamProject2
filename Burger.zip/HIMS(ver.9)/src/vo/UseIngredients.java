package vo;

public class UseIngredients {
	private int i_no;
	private String use_date;
	private int i_amount;

	public UseIngredients() {
		// TODO Auto-generated constructor stub
	}

	public UseIngredients(int i_no, String use_date, int i_amount) {
		super();
		this.i_no = i_no;
		this.use_date = use_date;
		this.i_amount = i_amount;
	}

	public int getI_no() {
		return i_no;
	}

	public void setI_no(int i_no) {
		this.i_no = i_no;
	}

	public String getUse_date() {
		return use_date;
	}

	public void setUse_date(String use_date) {
		this.use_date = use_date;
	}

	public int getI_amount() {
		return i_amount;
	}

	public void setI_amount(int i_amount) {
		this.i_amount = i_amount;
	}

	@Override
	public String toString() {
		return "UseIngredients [i_no=" + i_no + ", use_date=" + use_date + ", i_amount=" + i_amount + "]";
	}
}
