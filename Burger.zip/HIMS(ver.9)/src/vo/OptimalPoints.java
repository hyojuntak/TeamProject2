package vo;

public class OptimalPoints {
	private String i_name;
	private int i_amount;
	private String shortest_end_date;
	private int optimal_quantity;
	private String optimal_order_date;

	public OptimalPoints() {
		// TODO Auto-generated constructor stub
	}

	public OptimalPoints(String i_name, int i_amount, String shortest_end_date, int optimal_quantity,
			String optimal_order_date) {
		super();
		this.i_name = i_name;
		this.i_amount = i_amount;
		this.shortest_end_date = shortest_end_date;
		this.optimal_quantity = optimal_quantity;
		this.optimal_order_date = optimal_order_date;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public int getI_amount() {
		return i_amount;
	}

	public void setI_amount(int i_amount) {
		this.i_amount = i_amount;
	}

	public String getShortest_end_date() {
		return shortest_end_date;
	}

	public void setShortest_end_date(String shortest_end_date) {
		this.shortest_end_date = shortest_end_date;
	}

	public int getOptimal_quantity() {
		return optimal_quantity;
	}

	public void setOptimal_quantity(int optimal_quantity) {
		this.optimal_quantity = optimal_quantity;
	}

	public String getOptimal_order_date() {
		return optimal_order_date;
	}

	public void setOptimal_order_date(String optimal_order_date) {
		this.optimal_order_date = optimal_order_date;
	}

	@Override
	public String toString() {
		return "OptimalPoints [i_name=" + i_name + ", i_amount=" + i_amount + ", shortest_end_date=" + shortest_end_date
				+ ", optimal_quantity=" + optimal_quantity + ", optimal_order_date=" + optimal_order_date + "]";
	}
}
