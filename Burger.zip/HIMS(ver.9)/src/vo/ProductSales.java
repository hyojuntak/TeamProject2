package vo;

public class ProductSales {
	private String sales_date;
	private String p_name;
	private int p_amount;
	private int p_income;
	private double p_cost;
	private int p_pure_income;

	public ProductSales() {
		// TODO Auto-generated constructor stub
	}

	public ProductSales(String sales_date, String p_name, int p_amount, int p_income, double p_cost,
			int p_pure_income) {
		super();
		this.sales_date = sales_date;
		this.p_name = p_name;
		this.p_amount = p_amount;
		this.p_income = p_income;
		this.p_cost = p_cost;
		this.p_pure_income = p_pure_income;
	}

	public String getSales_date() {
		return sales_date;
	}

	public void setSales_date(String sales_date) {
		this.sales_date = sales_date;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getP_amount() {
		return p_amount;
	}

	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}

	public int getP_income() {
		return p_income;
	}

	public void setP_income(int p_income) {
		this.p_income = p_income;
	}

	public double getP_cost() {
		return p_cost;
	}

	public void setP_cost(double p_cost) {
		this.p_cost = p_cost;
	}

	public int getP_pure_income() {
		return p_pure_income;
	}

	public void setP_pure_income(int p_pure_income) {
		this.p_pure_income = p_pure_income;
	}

	@Override
	public String toString() {
		return "ProductSales [sales_date=" + sales_date + ", p_name=" + p_name + ", p_amount=" + p_amount
				+ ", p_income=" + p_income + ", p_cost=" + p_cost + ", p_pure_income=" + p_pure_income + "]";
	}
}
