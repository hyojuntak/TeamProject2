package vo;

public class Sales {
	private String sales_date;
	private int p_no;
	private int p_amount;

	public Sales() {
		// TODO Auto-generated constructor stub
	}

	public Sales(String sales_date, int p_no, int p_amount) {
		super();
		this.sales_date = sales_date;
		this.p_no = p_no;
		this.p_amount = p_amount;
	}

	public String getSales_date() {
		return sales_date;
	}

	public void setSales_date(String sales_date) {
		this.sales_date = sales_date;
	}

	public int getP_no() {
		return p_no;
	}

	public void setP_no(int p_no) {
		this.p_no = p_no;
	}

	public int getP_amount() {
		return p_amount;
	}

	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}

	@Override
	public String toString() {
		return "Sales [sales_date=" + sales_date + ", p_no=" + p_no + ", p_amount=" + p_amount + "]";
	}
}
