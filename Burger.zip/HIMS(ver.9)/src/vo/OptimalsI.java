package vo;

public class OptimalsI {
	private String i_name;
	private int i_amount;
	private int forecast;
	private String shortest_poc;
	private String optimal_time;

	public OptimalsI() {
		// TODO Auto-generated constructor stub
	}

	public OptimalsI(String i_name, int i_amount, int forecast, String shortest_poc, String optimal_time) {
		super();
		this.i_name = i_name;
		this.i_amount = i_amount;
		this.forecast = forecast;
		this.shortest_poc = shortest_poc;
		this.optimal_time = optimal_time;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public int getI_amount() {
		return i_amount;
	}

	public void setI_amount(int i_amount) {
		this.i_amount = i_amount;
	}

	public int getForecast() {
		return forecast;
	}

	public void setForecast(int forecast) {
		this.forecast = forecast;
	}

	public String getShortest_poc() {
		return shortest_poc;
	}

	public void setShortest_poc(String shortest_poc) {
		this.shortest_poc = shortest_poc;
	}

	public String getOptimal_time() {
		return optimal_time;
	}

	public void setOptimal_time(String optimal_time) {
		this.optimal_time = optimal_time;
	}

	@Override
	public String toString() {
		return "OptimalsI [i_name=" + i_name + ", i_amount=" + i_amount + ", forecast=" + forecast + ", shortest_poc="
				+ shortest_poc + ", optimal_time=" + optimal_time + "]";
	}
}
