package vo;

public class DailyStocks {
	private String order_date;
	private String i_name;
	private int i_amount;
	private String end_date;

	public DailyStocks() {
		// TODO Auto-generated constructor stub
	}

	public DailyStocks(String order_date, String i_name, int i_amount, String end_date) {
		super();
		this.order_date = order_date;
		this.i_name = i_name;
		this.i_amount = i_amount;
		this.end_date = end_date;
	}

	public String getOrder_date() {
		return order_date;
	}

	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public int getI_amount() {
		return i_amount;
	}

	public void setI_amount(int i_amount) {
		this.i_amount = i_amount;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	@Override
	public String toString() {
		return "DailyStocks [order_date=" + order_date + ", i_name=" + i_name + ", i_amount=" + i_amount + ", end_date="
				+ end_date + "]";
	}
}
