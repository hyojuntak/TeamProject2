package ui;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import dummy.DummyDAOManager;

@SuppressWarnings("serial")
public class MainMenu extends JFrame {
	Container pane;
	JButton option, order, insertSales, productsInfo, selectSales, updateIngre, selectStocks, selectOptimal;
			
	public MainMenu() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("HIMS");
		setBounds(50, 50, 600, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);

		pane = getContentPane();
		pane.setLayout(new GridLayout(4, 2));

		option = new JButton();
		order = new JButton();
		insertSales = new JButton();
		productsInfo = new JButton();
		selectSales = new JButton();
		updateIngre = new JButton();
		selectStocks = new JButton();
		selectOptimal = new JButton();
		
		option.setText("�� ����");
		order.setText("���� �Է�");
		insertSales.setText("�Ż� �Է�");
		productsInfo.setText("��ǰ ����");
		selectSales.setText("�Ż� ��ȸ");
		updateIngre.setText("���� ����");
		selectStocks.setText("��� ��ȸ");
		selectOptimal.setText("������ ��ȸ");

		pane.add(option);
		pane.add(order);
		pane.add(insertSales);
		pane.add(updateIngre);
		pane.add(productsInfo);
		pane.add(selectStocks);
		pane.add(selectSales);
		pane.add(selectOptimal);

		option.addActionListener(new EventHandler());
		order.addActionListener(new EventHandler());
		insertSales.addActionListener(new EventHandler());
		updateIngre.addActionListener(new EventHandler());
		productsInfo.addActionListener(new EventHandler());
		selectStocks.addActionListener(new EventHandler());
		selectSales.addActionListener(new EventHandler());
		selectOptimal.addActionListener(new EventHandler());

		setVisible(true);
	}



	class EventHandler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == option) {
				new Option();
			} else if (e.getSource() == order) {
				new Order();
			} else if (e.getSource() == insertSales) {
				new InsertSales();
			} else if (e.getSource() == updateIngre) {
				new UpdateIngre();
			} else if (e.getSource() == productsInfo) {
				new ProductsInfo();
			} else if (e.getSource() == selectStocks) {
				new SelectStocks();
			} else if (e.getSource() == selectSales) {
				new SelectSales();
			} else if (e.getSource() == selectOptimal) {
				new SelectOptimal();
			}
		}

	}
	public static void main(String[] args) {
		System.out.println("���� ������ �����͸� ��� �����ϰ�, ���� �����͸� ���� �Է� ���Դϴ�.");
		System.out.println("��ø� ��ٷ��ֽʽÿ�.");
		
		// ���� ������ �Է� ����
		DummyDAOManager ddmanager = new DummyDAOManager();
		ddmanager.deleteAllSales();
		ddmanager.deleteAllIngre();
		ddmanager.inputDummyIngre();
		ddmanager.inputDummySales();
		
		new MainMenu();
	}
}