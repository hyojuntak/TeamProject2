package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import dao.IngredientsDAOManager;
import dao.Today;

@SuppressWarnings("serial")
public class UpdateIngre extends JFrame {
	IngredientsDAOManager imanager = new IngredientsDAOManager();
	
	Container pane;
	JButton updateOrder, cancelOrder;
	
	public UpdateIngre() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("UpdateIngre");
		setBounds(50,50,800,800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		
		pane = getContentPane();
		pane.setLayout(new BorderLayout());
		
		updateOrder = new JButton("���� ����");
		cancelOrder = new JButton("���� ���");
		updateOrder.setSize(200, 150);
		cancelOrder.setSize(200, 150);
		updateOrder.addActionListener(new Handler());
		cancelOrder.addActionListener(new Handler());
		
		pane.add(updateOrder, BorderLayout.NORTH);
		pane.add(cancelOrder, BorderLayout.SOUTH);
		
		pack();
		setVisible(true);
	}
	
	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == updateOrder) {
				new UpdateOrder();
			} else if(e.getSource() == cancelOrder) {
				int result = imanager.deleteIngredients(Today.today());
				if(result != 0) {
					System.out.println("���� ���ְ� ��ҵǾ����ϴ�.");
					System.out.println(result + "�� ǰ���� ���ְ� ��ҵǾ����ϴ�.");
				}
			}
		}
	}
}
