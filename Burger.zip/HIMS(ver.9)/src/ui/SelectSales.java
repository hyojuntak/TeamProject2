package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class SelectSales extends JFrame {
	Container pane;
	JButton dailySales, productSales;
	
	public SelectSales() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("SelectSales");
		setBounds(50,50,800,800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		
		pane = getContentPane();
		pane.setLayout(new BorderLayout());
		
		productSales = new JButton("���ں� ���� ��ǰ �Ż� ��ȸ");
		dailySales = new JButton("���ں� �ѸŻ� ��ȸ");
		productSales.setSize(200, 150);
		dailySales.setSize(200, 150);
		productSales.addActionListener(new Handler());
		dailySales.addActionListener(new Handler());
		
		pane.add(productSales, BorderLayout.NORTH);
		pane.add(dailySales, BorderLayout.SOUTH);
		
		pack();
		setVisible(true);
	}
	
	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == productSales) {
				new ProductSales();
			} else if(e.getSource() == dailySales) {
				new DailySales();
			}
		}
	}
}
