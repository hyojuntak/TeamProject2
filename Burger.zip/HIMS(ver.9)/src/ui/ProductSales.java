package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class ProductSales extends JFrame {
	Container pane;
	JPanel upper, lower, middle;
	JLabel startDate, endDate, format1, format2, product;
	JTextField tf1, tf2;
	JButton cancel, select;
	JButton bulgogi, cheese, mushroom, chicken, pork;

	public ProductSales() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("ProductSales");
		setBounds(50, 50, 800, 800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);

		pane = getContentPane();
		pane.setLayout(new BorderLayout());

		startDate = new JLabel("��ȸ ���� ��¥ �Է�  ");
		endDate = new JLabel("��ȸ ���� ��¥ �Է�  ");
		format1 = new JLabel("'YYYYMMDD'�� �Է��� �ּ���.");
		format2 = new JLabel("'YYYYMMDD'�� �Է��� �ּ���.");
		tf1 = new JTextField(12);
		tf2 = new JTextField(12);
		tf1.setText("");
		tf2.setText("");

		upper = new JPanel();
		upper.setLayout(new FlowLayout());
		upper.add(startDate);
		upper.add(tf1);
		upper.add(format1);

		middle = new JPanel();
		middle.setLayout(new FlowLayout());
		middle.add(endDate);
		middle.add(tf2);
		middle.add(format2);

		cancel = new JButton("���");
		select = new JButton("��ȸ");
		cancel.addActionListener(new Handler());
		select.addActionListener(new Handler());

		bulgogi = new JButton("�Ұ��� ����");
		cheese = new JButton("ġ�� ����");
		mushroom = new JButton("�ӽ��� ������ũ ����");
		chicken = new JButton("ġŲ ����");
		pork = new JButton("��ũ ����");
		product = new JLabel("");
		product.setHorizontalAlignment(JLabel.CENTER);
		
		bulgogi.addActionListener(new Handler());
		cheese.addActionListener(new Handler());
		mushroom.addActionListener(new Handler());
		chicken.addActionListener(new Handler());
		pork.addActionListener(new Handler());

		lower = new JPanel();
		lower.setLayout(new GridLayout(2, 4));
		lower.add(bulgogi);
		lower.add(cheese);
		lower.add(mushroom);
		lower.add(product);
		lower.add(chicken);
		lower.add(pork);
		lower.add(select);
		lower.add(cancel);

		pane.add(upper, BorderLayout.NORTH);
		pane.add(middle, BorderLayout.CENTER);
		pane.add(lower, BorderLayout.SOUTH);

		pack();
		setVisible(true);
	}

	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == bulgogi) {
				product.setText(bulgogi.getText());
			} else if(e.getSource() == cheese) {
				product.setText(cheese.getText());
			}else if(e.getSource() == mushroom) {
				product.setText(mushroom.getText());
			}else if(e.getSource() == chicken) {
				product.setText(chicken.getText());
			}else if(e.getSource() == pork) {
				product.setText(pork.getText());
			}
			
			if(e.getSource() == select) {
				if(tf1.getText().matches("^(19|20)[0-9][0-9](0[1-9]|1[012])(0[1-9]|[1-2][0-9]|3[0-1])$")) {
					if(tf2.getText().matches("^(19|20)[0-9][0-9](0[1-9]|1[012])(0[1-9]|[1-2][0-9]|3[0-1])$")) {
						if(Integer.parseInt(tf1.getText()) <= Integer.parseInt(tf2.getText())) {
							switch(product.getText()) {
							case "�Ұ��� ����":
								new ProductSalesTable(tf1.getText(), tf2.getText(), 1);
								break;
							case "ġ�� ����":
								new ProductSalesTable(tf1.getText(), tf2.getText(), 2);
								break;
							case "�ӽ��� ������ũ ����":
								new ProductSalesTable(tf1.getText(), tf2.getText(), 3);
								break;
							case "ġŲ ����":
								new ProductSalesTable(tf1.getText(), tf2.getText(), 4);
								break;
							case "��ũ ����":
								new ProductSalesTable(tf1.getText(), tf2.getText(), 5);
								break;
							default :
								System.out.println("��ȸ�Ͻ� ��ǰ�� �����Ͻʽÿ�.");	
								break;
							}
							return;
						}
					}
				}				
				System.out.println("�߸��� ������ �Է��Դϴ�.");
				tf1.setText("");
				tf2.setText("");
			} else if(e.getSource() == cancel) {
				tf1.setText("");
				tf2.setText("");
			}
		}
	}
}
