package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.SalesDAOManager;
import dao.Today;
import vo.Sales;

@SuppressWarnings("serial")
public class InsertSales extends JFrame {
	SalesDAOManager smanager = new SalesDAOManager();
	private static final int PRODUCTNUM = 5;
	
	Container pane;
	JPanel upper, lower;
	JTextField[] tf;
	JLabel[] jlArr;
	JButton cancel, input;
	
	public InsertSales() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("InsertSales");
		setBounds(50,50,800,800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		
		pane = getContentPane();
		pane.setLayout(new BorderLayout());
		
		upper = new JPanel();
		lower = new JPanel();
		
		upper.setLayout(new GridLayout(PRODUCTNUM, 2));
		lower.setLayout(new FlowLayout());
		
		jlArr = new JLabel[PRODUCTNUM];
		tf = new JTextField[PRODUCTNUM];
		
		for (int i=0; i < PRODUCTNUM; i++) {
			jlArr[i] = new JLabel();
			tf[i] = new JTextField("");
			upper.add(jlArr[i]);
			upper.add(tf[i]);
		}
		
		jlArr[0].setText("�Ұ��� ����  ");
		jlArr[1].setText("ġ�� ����  ");
		jlArr[2].setText("�ӽ��� ������ũ ����  ");
		jlArr[3].setText("ġŲ ����  ");
		jlArr[4].setText("��ũ ����  ");
		
		cancel = new JButton();
		input = new JButton();
		cancel.setText("���");
		input.setText("�Է�");
		cancel.setSize(150 , 100);
		input.setSize(150, 100);
		
		cancel.addActionListener(new Handler());
		input.addActionListener(new Handler());
		
		lower.add(input);
		lower.add(cancel);
		
		pane.add(upper, BorderLayout.NORTH);
		pane.add(lower, BorderLayout.SOUTH);
		pack();
		setVisible(true);
	}
	
	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			int result = 0;
			
			if (e.getSource() == input) {
				for(int i = 0; i<PRODUCTNUM; i++) {
					if(tf[i].getText().equals("")) continue;
					Sales sales = new Sales(Today.today(), i + 1, Integer.parseInt(tf[i].getText()));
					result += smanager.insertSales(sales);
				}
			} else if (e.getSource() == cancel) {
				for(int i=0; i < PRODUCTNUM; i++) {
					tf[i].setText("");
				}
			}
			
			if(result != 0) {
				System.out.println(result + "�� ��ǰ�� �Ż��� �ԷµǾ����ϴ�.");
			}
		}
	}
}
