package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class SelectStocks extends JFrame {
	Container pane;
	JButton dailyStocks, ingreStocks;
	
	public SelectStocks() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("SelectStocks");
		setBounds(50,50,800,800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		
		pane = getContentPane();
		pane.setLayout(new BorderLayout());
		
		dailyStocks = new JButton("���� ���ں� ��ȸ");
		ingreStocks = new JButton("��� ǰ�� ��ȸ");
		dailyStocks.setSize(200, 150);
		ingreStocks.setSize(200, 150);
		dailyStocks.addActionListener(new Handler());
		ingreStocks.addActionListener(new Handler());
		
		pane.add(dailyStocks, BorderLayout.NORTH);
		pane.add(ingreStocks, BorderLayout.SOUTH);
		
		pack();
		setVisible(true);
	}
	
	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == dailyStocks) {
				new DailyStocks();
			} else if(e.getSource() == ingreStocks) {
				new IngreStocks();
			}
		}
	}
}
