package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.OptimalPointsDAOManager;

@SuppressWarnings("serial")
public class Option extends JFrame {
	OptimalPointsDAOManager opmanager = new OptimalPointsDAOManager();
	private static final int OPTIONNUM = 7;

	Container pane;
	JPanel upper, lower;
	JTextField[] tf;
	JLabel[] jlArr;
	JButton cancel, input;

	public Option() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("Option");
		setBounds(50, 50, 800, 800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);

		pane = getContentPane();
		pane.setLayout(new BorderLayout());

		upper = new JPanel();
		lower = new JPanel();

		upper.setLayout(new GridLayout(OPTIONNUM, 2));
		lower.setLayout(new FlowLayout());

		jlArr = new JLabel[OPTIONNUM];
		tf = new JTextField[OPTIONNUM];

		for (int i = 0; i < OPTIONNUM; i++) {
			jlArr[i] = new JLabel();
			tf[i] = new JTextField("");
			upper.add(jlArr[i]);
			upper.add(tf[i]);
		}

		jlArr[0].setText("��Ȱ��� ����  ");
		jlArr[1].setText("�м� ���� �Ⱓ ����  ");
		jlArr[2].setText("�Ұ��� ���� ���� ���� ���䷮ ����  ");
		jlArr[3].setText("ġ�� ���� ���� ���� ���䷮ ����  ");
		jlArr[4].setText("�ӽ��� ������ũ ���� ���� ���� ���䷮ ����  ");
		jlArr[5].setText("ġŲ ���� ���� ���� ���䷮ ����  ");
		jlArr[6].setText("��ũ ���� ���� ���� ���䷮ ����  ");

		tf[0].setText(opmanager.getSmoothingCoefficient() + "");
		tf[1].setText(opmanager.getAnalysisPeriod() + "");
		tf[2].setText(opmanager.getFirstForecast(1) + "");
		tf[3].setText(opmanager.getFirstForecast(2) + "");
		tf[4].setText(opmanager.getFirstForecast(3) + "");
		tf[5].setText(opmanager.getFirstForecast(4) + "");
		tf[6].setText(opmanager.getFirstForecast(5) + "");

		cancel = new JButton();
		input = new JButton();
		cancel.setText("���");
		input.setText("�Է�");
		cancel.setSize(150, 100);
		input.setSize(150, 100);

		cancel.addActionListener(new Handler());
		input.addActionListener(new Handler());

		lower.add(input);
		lower.add(cancel);

		pane.add(upper, BorderLayout.NORTH);
		pane.add(lower, BorderLayout.SOUTH);
		pack();
		setVisible(true);
	}

	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			int result = 0;

			if (e.getSource() == input) {
				for (int i = 0; i < OPTIONNUM; i++) {
					if (tf[i].getText().equals(""))
						continue;
					if (i == 0) {
						result += opmanager.setSmoothingCoefficient(Double.parseDouble(tf[i].getText()));
						continue;
					}
					if (i == 1) {
						result += opmanager.setAnalysisPeriod(Integer.parseInt(tf[i].getText()));
						continue;
					}
					Map<String, Object> map = new HashMap<>();
					map.put("p_no", i - 1);
					map.put("first_forecast", Integer.parseInt(tf[i].getText()));
					result += opmanager.setFirstForecast(map);
				}
			} else if (e.getSource() == cancel) {
				for (int i = 0; i < OPTIONNUM; i++) {
					tf[i].setText("");
				}
			}

			if (result != 0) {
				System.out.println(result + "�� �׸��� ���� �����Ǿ����ϴ�.");
			}
		}
	}
}
