package ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.IngredientsDAOManager;
import dao.Today;
import vo.Ingredients;

@SuppressWarnings("serial")
public class UpdateOrder extends JFrame {
	private IngredientsDAOManager imanager = new IngredientsDAOManager();
	private static final int INGRENUM = 11;

	Container pane;
	JPanel upper, lower;
	JTextField[] tf;
	JLabel[][] jlArr;
	JButton cancel, order;

	public UpdateOrder() {
		Toolkit kit = Toolkit.getDefaultToolkit();
		Image img = kit.getImage("bg.png");
		setIconImage(img);
		setTitle("Order");
		setBounds(50, 50, 800, 800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);

		pane = getContentPane();
		pane.setLayout(new BorderLayout());

		upper = new JPanel();
		lower = new JPanel();

		upper.setLayout(new GridLayout(INGRENUM, 3));
		lower.setLayout(new FlowLayout());

		jlArr = new JLabel[INGRENUM][2];
		tf = new JTextField[INGRENUM];

		for (int i = 0; i < INGRENUM; i++) {
			for (int j = 0; j < 3; j++) {
				if (j == 2) {
					tf[i] = new JTextField("");
					upper.add(tf[i]);
					continue;
				}
				jlArr[i][j] = new JLabel();
				upper.add(jlArr[i][j]);
			}
		}

		jlArr[0][0].setText("�Ұ���  ");
		jlArr[1][0].setText("��������  ");
		jlArr[2][0].setText("�߰���  ");
		jlArr[3][0].setText("������  ");
		jlArr[4][0].setText("��  ");
		jlArr[5][0].setText("ġ��  ");
		jlArr[6][0].setText("�����  ");
		jlArr[7][0].setText("�丶��  ");
		jlArr[8][0].setText("����  ");
		jlArr[9][0].setText("��ø  ");
		jlArr[10][0].setText("�ӽ�Ÿ��  ");

		jlArr[0][1].setText("gram  ");
		jlArr[1][1].setText("gram  ");
		jlArr[2][1].setText("gram  ");
		jlArr[3][1].setText("gram  ");
		jlArr[4][1].setText("gram  ");
		jlArr[5][1].setText("gram  ");
		jlArr[6][1].setText("gram  ");
		jlArr[7][1].setText("gram  ");
		jlArr[8][1].setText("gram  ");
		jlArr[9][1].setText("gram  ");
		jlArr[10][1].setText("gram  ");

		cancel = new JButton();
		order = new JButton();
		cancel.setText("���");
		order.setText("���� ����");
		cancel.setSize(150, 100);
		order.setSize(150, 100);

		cancel.addActionListener(new Handler());
		order.addActionListener(new Handler());

		lower.add(order);
		lower.add(cancel);

		pane.add(upper, BorderLayout.NORTH);
		pane.add(lower, BorderLayout.SOUTH);
		pack();
		setVisible(true);
	}

	class Handler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			int result = 0;
			
			if (e.getSource() == order) {
				for (int i = 0; i < INGRENUM; i++) {
					if (tf[i].getText().equals(""))
						continue;
					Ingredients ingre = new Ingredients(i + 1, Today.today(), Integer.parseInt(tf[i].getText()));
					result += imanager.updateIngredients(ingre);
				}
			} else if (e.getSource() == cancel) {
				for (int i = 0; i < INGRENUM; i++) {
					tf[i].setText("");
				}
			}
			
			if(result != 0) {
				System.out.println(result + "�� ǰ���� ���ְ� ���� �����Ǿ����ϴ�.");
			}
		}
	}
}
