package dummy;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import dao.IngredientsDAO;
import dao.MybatisConfig;
import dao.SalesDAO;
import vo.Ingredients;
import vo.Sales;

public class DummyDAOManager {
	private SqlSessionFactory factory = MybatisConfig.getSqlSessionFactory();

	public int inputDummySales() {
		SqlSession session = factory.openSession();
		SalesDAO dao = session.getMapper(SalesDAO.class);
		int year = 0;
		int month = 0;
		int day = 0;
		int rouletteNum = 5;
		int p_no = 0;
		int p_amount = 0;
		int result = 0;

		for (year = 2017; year < 2019; year++) {
			for (month = 1; month < 13; month++) {
				for (day = 1; day < 28; day++) {
					if (month < 10) {
						if (day < 10) {
							String date = String.valueOf(year) + "0" + String.valueOf(month) + "0"
									+ String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								p_no = i + 1;
								p_amount = (int) (Math.random() * 300 + 30);
								Sales sales = new Sales(date, p_no, p_amount);
								result += dao.insertSales(sales);
								session.commit();
							}
						} else {
							String date = String.valueOf(year) + "0" + String.valueOf(month) + String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								p_no = i + 1;
								p_amount = (int) (Math.random() * 300 + 30);
								Sales sales = new Sales(date, p_no, p_amount);
								result += dao.insertSales(sales);
								session.commit();
							}
						}
					} else {
						if (day < 10) {
							String date = String.valueOf(year) + String.valueOf(month) + "0" + String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								p_no = i + 1;
								p_amount = (int) (Math.random() * 300 + 30);
								Sales sales = new Sales(date, p_no, p_amount);
								result += dao.insertSales(sales);
								session.commit();
							}
						} else {
							String date = String.valueOf(year) + String.valueOf(month) + String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								p_no = i + 1;
								p_amount = (int) (Math.random() * 300 + 30);
								Sales sales = new Sales(date, p_no, p_amount);
								result += dao.insertSales(sales);
								session.commit();
							}
						}
					}
				}
			}
		}
		dao.clearDummy();
		session.commit();
		session.close();
		return result;
	}

	public int inputDummyIngre() {
		SqlSession session = factory.openSession();
		IngredientsDAO dao = session.getMapper(IngredientsDAO.class);
		int year = 0;
		int month = 0;
		int day = 0;
		int rouletteNum = 11;
		int i_no = 0;
		int i_amount = 0;
		int result = 0;
		
		for (year = 2017; year < 2019; year++) {
			for (month = 1; month < 13; month++) {
				for (day = 1; day < 28; day++) {
					if (month < 10) {
						if (day < 10) {
							String date = String.valueOf(year) + "0" + String.valueOf(month) + "0"
									+ String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								i_no = i + 1;
								i_amount = (int) ((Math.random() * 100) * 100 + 10000);
								Ingredients ingre = new Ingredients(i_no, date, i_amount);
								result += dao.insertIngredients(ingre);
								session.commit();
							}
						} else {
							String date = String.valueOf(year) + "0" + String.valueOf(month) + String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								i_no = i + 1;
								i_amount = (int) ((Math.random() * 100) * 100 + 10000);
								Ingredients ingre = new Ingredients(i_no, date, i_amount);
								result += dao.insertIngredients(ingre);
								session.commit();
							}
						}
					} else {
						if (day < 10) {
							String date = String.valueOf(year) + String.valueOf(month) + "0" + String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								i_no = i + 1;
								i_amount = (int) ((Math.random() * 100) * 100 + 10000);
								Ingredients ingre = new Ingredients(i_no, date, i_amount);
								result += dao.insertIngredients(ingre);
								session.commit();
							}
						} else {
							String date = String.valueOf(year) + String.valueOf(month) + String.valueOf(day);
							for (int i = 0; i < rouletteNum; i++) {
								i_no = i + 1;
								i_amount = (int) ((Math.random() * 100) * 100 + 10000);
								Ingredients ingre = new Ingredients(i_no, date, i_amount);
								result += dao.insertIngredients(ingre);
								session.commit();
							}
						}
					}
				}
			}
		}
		dao.clearDummy();
		session.commit();
		session.close();
		return result;
	}
	
	public int deleteAllSales() {
		SqlSession session = factory.openSession();
		SalesDAO dao = session.getMapper(SalesDAO.class);
		int result = dao.deleteAllSales();
		session.commit();
		session.close();
		return result;
	}
	
	public int deleteAllIngre() {
		SqlSession session = factory.openSession();
		IngredientsDAO dao = session.getMapper(IngredientsDAO.class);
		int result = dao.deleteAllIngre();
		session.commit();
		session.close();
		return result;
	}
}
