--Run sql command line���� ���ɹ� ����
conn hr/hr as sysdba;
create user hims identified by hims;
grant connect to hims;
grant all privilege to hims;
exit;

--hims�������� �����Ͽ� table ���� �� data �Է�
create table meta_ingredients(
  i_no number constraint metai_ino_pk primary key,
  i_name varchar2(30) constraint metai_iname_nn not null,
  period_of_circulation number,
  order_price number,
  order_unit number,
  delivery_time number
);

create table meta_products(
  p_no number constraint metap_pno_pk primary key,
  p_name varchar2(30) constraint metap_pname_nn not null,
  price number constraint metap_price_nn not null
);

create table meta_pi(
  p_no number constraint metapi_pno_fk references meta_products,
  i_no number constraint metapi_ino_fk references meta_ingredients,
  amount number constraint metapi_amount_nn not null
);

create table ingredients(
  i_no number,
  order_date date default sysdate,
  i_amount number,
  constraint ingredients_pk primary key(i_no, order_date),
  constraint ingredients_ino_fk foreign key(i_no) references meta_ingredients
);

create table sales(
  sales_date date default sysdate,
  p_no number constraint sales_pno_fk references meta_products,
  p_amount number,
  constraint sales_pk primary key(sales_date, p_no)
);

create table optimals(
  p_no number constraint optimals_pno_pk primary key,
  first_forcast number,
  correlation number,
  demand_forecast number,
  constraint optimals_pno_fk foreign key(p_no) references meta_products
);

create table optimals_i(
  i_no number constraint optimalsi_ino_pk primary key,
  i_amount number default 0,
  forecast number,
  shortest_poc date,
  optimal_time date,
  constraint optimalsi_ino_fk foreign key(i_no) references meta_ingredients
);

create table options(
  o_name varchar2(30) constraint options_oname_pk primary key,
  value number constraint options_value_nn not null
);

insert into options values('smoothing coefficient', 0.2);
insert into options values('analysis period', 180);

insert into meta_ingredients values(1,'beef',180,18000,1200,3);
insert into meta_ingredients values(2,'pork',180,16000,1200,3);
insert into meta_ingredients values(3,'chicken',180,12000,1200,3);
insert into meta_ingredients values(4,'bacon',30,8000,1000,3);
insert into meta_ingredients values(5,'bread',6,30000,3000,2);
insert into meta_ingredients values(6,'cheese',70,3000,900,2);
insert into meta_ingredients values(7,'lettuce',7,6000,1400,1);
insert into meta_ingredients values(8,'tomato',7,3000,1000,1);
insert into meta_ingredients values(9,'mushroom',4,8000,1000,3);
insert into meta_ingredients values(10,'ketchup',360,5000,3000,5);
insert into meta_ingredients values(11,'mustard',360,5000,3000,5);

insert into meta_products values(1,'bulgogi burger',5000);
insert into meta_products values(2,'cheese burger',6200);
insert into meta_products values(3,'mushroom stake burger',8800);
insert into meta_products values(4,'chicken burger',7500);
insert into meta_products values(5,'pork burger',8000);

insert into meta_pi values(1,5,60);
insert into meta_pi values(1,2,120);
insert into meta_pi values(1,7,12);
insert into meta_pi values(1,10,10);

insert into meta_pi values(2,5,60);
insert into meta_pi values(2,1,120);
insert into meta_pi values(2,7,14);
insert into meta_pi values(2,10,10);
insert into meta_pi values(2,6,20);

insert into meta_pi values(3,5,60);
insert into meta_pi values(3,1,140);
insert into meta_pi values(3,7,18);
insert into meta_pi values(3,10,8);
insert into meta_pi values(3,11,8);
insert into meta_pi values(3,6,20);
insert into meta_pi values(3,8,5);
insert into meta_pi values(3,4,15);
insert into meta_pi values(3,9,10);

insert into meta_pi values(4,5,60);
insert into meta_pi values(4,3,120);
insert into meta_pi values(4,7,12);
insert into meta_pi values(4,10,8);
insert into meta_pi values(4,11,8);
insert into meta_pi values(4,8,5);

insert into meta_pi values(5,5,60);
insert into meta_pi values(5,2,140);
insert into meta_pi values(5,7,16);
insert into meta_pi values(5,11,12);
insert into meta_pi values(5,8,10);
insert into meta_pi values(5,4,20);

insert into optimals(p_no, first_forcast) values(1, 200);
insert into optimals(p_no, first_forcast) values(2, 200);
insert into optimals(p_no, first_forcast) values(3, 200);
insert into optimals(p_no, first_forcast) values(4, 200);
insert into optimals(p_no, first_forcast) values(5, 200);

insert into optimals_i(i_no) values(1);
insert into optimals_i(i_no) values(2);
insert into optimals_i(i_no) values(3);
insert into optimals_i(i_no) values(4);
insert into optimals_i(i_no) values(5);
insert into optimals_i(i_no) values(6);
insert into optimals_i(i_no) values(7);
insert into optimals_i(i_no) values(8);
insert into optimals_i(i_no) values(9);
insert into optimals_i(i_no) values(10);
insert into optimals_i(i_no) values(11);

commit;